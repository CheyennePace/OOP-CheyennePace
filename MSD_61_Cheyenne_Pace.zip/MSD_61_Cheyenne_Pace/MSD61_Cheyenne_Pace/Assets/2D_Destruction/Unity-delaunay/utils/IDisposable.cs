namespace Delaunay
{
	namespace Utils
	{
		public interface IDisposable
		{
			void Dispose ();
		}
	}
}